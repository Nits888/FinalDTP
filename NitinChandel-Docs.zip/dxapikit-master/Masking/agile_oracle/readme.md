## readme.md

A complete API example for Masking Oracle Table(s), please see image contents in ...<br />
<br />
agile_oracle_command_line.png<br />	
agile_oracle_flow.png<br />
<br />
and modify the Masking parameters in agile_oracle.sh file <br />
<br />
