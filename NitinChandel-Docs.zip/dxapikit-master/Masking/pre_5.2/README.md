# README.md



Masking 
- Shell Masking Job Script ............................ Filename: AgileMaskingExternalCalling.sh
- wget Command Masking Job Script .......... Filename: wget_local.sh

Masking Logs/Report
- Get Masking Logs - Shell ........................... Filename: get_dmsuite_log.sh
- Get Masking Logs - Python ........................ Filename: get_dmsuite_log.py
- Get Monitor Jobs Report ............................ Filename: monitor_jobs_report.sh
	
