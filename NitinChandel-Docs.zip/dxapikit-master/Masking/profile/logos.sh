#!/bin/bash

#
# Default Delphix Logo ...
#
LOGO="../logos/delphix-logo-black_300w.png" 
#
# Customer Logos ...
#
#LOGO="../logos/dell_logo.png\" height=\"75\"" 
#LOGO="../logos/deloitte.png\" height=\"50\""  
#LOGO="../logos/Askida_RGB.png\" height=\"50\""
#LOGO="../logos/Bell_logo.png\" height=\"50\""
#LOGO="../logos/intact_logo.png\" height=\"50\""
#LOGO="../logos/logimethod_logo.png\" height=\"50\""
#LOGO="../logos/National_Bank_CA.jpg\" height=\"50\"" 
#LOGO="../logos/Askida_RGB.png\" height=\"45\"><image src=\"images/Bell_logo.png\" height=\"50\"><image src=\"images/intact_logo.png\" height=\"50\"><image src=\"images/logimethod_logo.png\" height=\"50\"><image src=\"images/National_Bank_CA.jpg\" height=\"50\""
#LOGO="../logos/actlogo.png\" height=\"75\""
#LOGO="../logos/logo_amway_en.png\" height=\"75\""
#LOGO="../logos/fedex.jpg\" height=\"125\""
LOGO="../logos/amfam_logo.png"
#LOGO="../logos/trans_america.png"
#LOGO="../logos/delta-dental-logo-no-text.png"
#LOGO="../logos/td_ameritrade1.png\" height=\"50\""
LOGO="../logos/jpmc_logo.png\" height=\"25\""
#LOGO="../logos/eharmony.png\" height=\"75\""
#LOGO="../logos/the-hartford.png\" height=\"75\""
#LOGO="../logos/Morgan_Stanley_Logo_1.png\" height=\"75\""
#LOGO="../logos/miso.png\" height=\"75\""
LOGO="../logos/CM_Logo_color1.png"

