readme.md

see README.txt 
