# README.md

Masking 
- Powershell Masking Job Script .................. Filename: masking_pre_5_2.ps1
