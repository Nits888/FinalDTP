# README.txt

Python Example<br />
Filename: auth.py<br />	

PHP Example<br />
Filename: delphix_curl.php<br />

Perl Example<br />
Filename: perl_curl.pl<br />

JSP Example (Requires JSP Server such as Tomcat)<br />
Filename: delphix_http.jsp<br />

Java Example<br />
Filename: delphix_sample.java<br />

Java Example (Requires json-simple-1.1.jar) <br />
Filename: delphix_sync_simple.java<br />

## Other Projects of Interest

**dxtoolkit** Great Perl Library of Programs that use the Delphix APIs 
https://github.com/delphix/dxtoolkit

**delphixpy** and **delphixpy-examples** Delphix Python Module and great set of Example Python Programs using delphixpy module.  
https://github.com/CloudSurgeon/delphixpy-examples



*** End of README.txt ***
